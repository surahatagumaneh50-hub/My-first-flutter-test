# SG Group Flutter Website

A small responsive portfolio website built with Flutter Web.

## Run locally
1. Install Flutter and enable web support.
2. In this folder, run:
   ```bash
   flutter pub get
   flutter run -d chrome
   ```

## Deploy to GitHub Pages
1. Create a new GitHub repository and upload these files.
2. Open **Settings → Pages** and set the source to **GitHub Actions**.
3. Push to the `main` branch. The workflow builds Flutter Web and publishes `build/web`.

The workflow automatically uses the repository name as the GitHub Pages base path.

## Customize
- Edit content and colors in `lib/main.dart`.
- Change the contact email in the contact section.
- The contact buttons are starter placeholders; add `url_launcher` if you want them to open email apps directly.
