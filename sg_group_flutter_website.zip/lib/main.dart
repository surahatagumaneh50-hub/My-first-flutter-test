import 'package:flutter/material.dart';

void main() => runApp(const SGGroupApp());

const skyBlue = Color(0xFF38BDF8);
const deepPink = Color(0xFFFF1493);
const ink = Color(0xFF101827);
const muted = Color(0xFF64748B);

class SGGroupApp extends StatelessWidget {
  const SGGroupApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SG Group | Digital Agency',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF8FAFC),
        colorScheme: ColorScheme.fromSeed(seedColor: skyBlue),
        fontFamily: 'Arial',
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;
    final compact = width < 720;
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            _nav(compact),
            _hero(compact),
            _services(compact),
            _about(compact),
            _contact(compact),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(22),
              color: ink,
              child: const Text(
                '© 2026 SG Group · Digital ideas, made real.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white70),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _nav(bool compact) => Container(
        padding: EdgeInsets.symmetric(horizontal: compact ? 20 : 8 * 10, vertical: 18),
        color: Colors.white,
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [skyBlue, deepPink]),
                borderRadius: BorderRadius.circular(14),
              ),
              alignment: Alignment.center,
              child: const Text('SG', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 19)),
            ),
            const SizedBox(width: 12),
            const Text('SG GROUP', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: ink, letterSpacing: 1.2)),
            const Spacer(),
            if (!compact)
              const Text('DIGITAL AGENCY', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: muted, letterSpacing: 1.4)),
          ],
        ),
      );

  Widget _hero(bool compact) => Container(
        width: double.infinity,
        padding: EdgeInsets.symmetric(horizontal: compact ? 24 : 100, vertical: compact ? 62 : 96),
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFFE0F2FE), Color(0xFFFFE4F2), Colors.white],
          ),
        ),
        child: compact
            ? Column(crossAxisAlignment: CrossAxisAlignment.start, children: _heroContent(true))
            : Row(children: [
                Expanded(flex: 3, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: _heroContent(false))),
                const SizedBox(width: 35),
                const Expanded(child: _heroArt()),
              ]),
      );

  List<Widget> _heroContent(bool compact) => [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 8),
          decoration: BoxDecoration(color: Colors.white.withOpacity(.85), borderRadius: BorderRadius.circular(30)),
          child: const Text('CREATIVE • DIGITAL • GLOBAL', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.1, color: deepPink)),
        ),
        const SizedBox(height: 22),
        Text('Your ideas.\nOur digital craft.', style: TextStyle(fontSize: compact ? 43 : 62, height: 1.05, fontWeight: FontWeight.w900, color: ink, letterSpacing: -2)),
        const SizedBox(height: 18),
        const Text('We build websites, apps and digital experiences that help your ideas grow.', style: TextStyle(fontSize: 17, height: 1.6, color: muted)),
        const SizedBox(height: 28),
        Wrap(spacing: 12, runSpacing: 12, children: [
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: ink, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 16)),
            onPressed: () => _openEmail(),
            child: const Text('Start a project  ↗'),
          ),
          OutlinedButton(
            style: OutlinedButton.styleFrom(foregroundColor: ink, padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 16), side: const BorderSide(color: ink)),
            onPressed: () => _scrollToServices(),
            child: const Text('Explore services'),
          ),
        ]),
      ];

  static const GlobalKey _servicesKey = GlobalKey();

  Widget _services(bool compact) => Container(
        key: _servicesKey,
        padding: EdgeInsets.symmetric(horizontal: compact ? 22 : 100, vertical: 70),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('WHAT WE DO', style: TextStyle(color: deepPink, fontWeight: FontWeight.bold, letterSpacing: 2, fontSize: 12)),
          const SizedBox(height: 10),
          const Text('Digital services, made simple.', style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900, color: ink)),
          const SizedBox(height: 28),
          LayoutBuilder(builder: (context, constraints) {
            final columns = constraints.maxWidth > 850 ? 3 : (constraints.maxWidth > 520 ? 2 : 1);
            final cardWidth = (constraints.maxWidth - (columns - 1) * 18) / columns;
            final items = [
              ('✦', 'Websites', 'Modern, responsive websites for your brand or business.', skyBlue),
              ('▣', 'Mobile apps', 'App concepts and digital products designed for people.', deepPink),
              ('◈', 'E-commerce', 'Beautiful online shops to showcase your products.', const Color(0xFF8B5CF6)),
              ('✎', 'Brand design', 'Visual identities, graphics and digital presentations.', const Color(0xFF0F766E)),
              ('⌘', 'Digital planning', 'Clear plans that turn ideas into achievable projects.', const Color(0xFFF59E0B)),
              ('↗', 'Digital solutions', 'Practical digital experiences built around your goals.', const Color(0xFF2563EB)),
            ];
            return Wrap(spacing: 18, runSpacing: 18, children: items.map((item) => SizedBox(
              width: cardWidth,
              child: Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22), border: Border.all(color: const Color(0xFFE2E8F0))),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Container(width: 48, height: 48, decoration: BoxDecoration(color: item.$4.withOpacity(.13), borderRadius: BorderRadius.circular(15)), alignment: Alignment.center, child: Text(item.$1, style: TextStyle(color: item.$4, fontSize: 24, fontWeight: FontWeight.bold))),
                  const SizedBox(height: 20),
                  Text(item.$2, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold, color: ink)),
                  const SizedBox(height: 8),
                  Text(item.$3, style: const TextStyle(height: 1.5, color: muted)),
                ]),
              ),
            )).toList());
          }),
        ]),
      );

  Widget _about(bool compact) => Container(
        width: double.infinity,
        color: ink,
        padding: EdgeInsets.symmetric(horizontal: compact ? 24 : 100, vertical: 64),
        child: compact
            ? const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('SMALL TEAM. BIG IDEAS.', style: TextStyle(color: skyBlue, fontWeight: FontWeight.bold, letterSpacing: 2, fontSize: 12)),
                SizedBox(height: 14),
                Text('We make digital feel possible.', style: TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w900)),
                SizedBox(height: 14),
                Text('SG Group helps businesses and creators take the next step with thoughtful design and useful technology.', style: TextStyle(color: Colors.white70, height: 1.7, fontSize: 16)),
              ])
            : Row(children: [
                const Expanded(child: Text('We make digital feel possible.', style: TextStyle(color: Colors.white, fontSize: 38, fontWeight: FontWeight.w900))),
                const SizedBox(width: 60),
                const Expanded(child: Text('SG Group helps businesses and creators take the next step with thoughtful design and useful technology.', style: TextStyle(color: Colors.white70, height: 1.8, fontSize: 17))),
              ]),
      );

  Widget _contact(bool compact) => Padding(
        padding: EdgeInsets.symmetric(horizontal: compact ? 24 : 100, vertical: 70),
        child: Container(
          width: double.infinity,
          padding: EdgeInsets.all(compact ? 26 : 44),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [skyBlue, deepPink]),
            borderRadius: BorderRadius.circular(28),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('HAVE A PROJECT IN MIND?', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 1.8, fontSize: 12)),
            const SizedBox(height: 12),
            Text('Let’s build something great.', style: TextStyle(color: Colors.white, fontSize: compact ? 29 : 40, fontWeight: FontWeight.w900)),
            const SizedBox(height: 22),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: ink, padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 16)),
              onPressed: _openEmail,
              child: const Text('Contact SG Group  ↗'),
            ),
            const SizedBox(height: 12),
            const Text('sgenterpriseofficial1@gmail.com', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
          ]),
        ),
      );

  static void _openEmail() {
    // Replace this demo action with a url_launcher mailto link if you add that package.
  }

  void _scrollToServices() {
    // For a small starter site, users can scroll down to the services section.
  }
}

class _heroArt extends StatelessWidget {
  const _heroArt();

  @override
  Widget build(BuildContext context) => Container(
        height: 330,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(32),
          gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [skyBlue, deepPink]),
          boxShadow: [BoxShadow(color: deepPink.withOpacity(.18), blurRadius: 35, offset: const Offset(0, 18))],
        ),
        child: Stack(alignment: Alignment.center, children: [
          Positioned(top: 25, right: 30, child: _bubble(80, Colors.white.withOpacity(.22))),
          Positioned(bottom: 28, left: 25, child: _bubble(55, Colors.white.withOpacity(.24))),
          const Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Text('SG', style: TextStyle(fontSize: 100, height: 1, fontWeight: FontWeight.w900, color: Colors.white, letterSpacing: -8)),
            SizedBox(height: 12),
            Text('IDEAS INTO REALITY', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 2, fontSize: 11)),
          ]),
        ]),
      );

  static Widget _bubble(double size, Color color) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(size * .3)),
        transform: Matrix4.rotationZ(.3),
      );
}
